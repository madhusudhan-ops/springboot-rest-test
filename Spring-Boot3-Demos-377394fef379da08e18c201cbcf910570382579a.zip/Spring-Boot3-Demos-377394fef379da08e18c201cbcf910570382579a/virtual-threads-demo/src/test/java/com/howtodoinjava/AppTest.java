package com.howtodoinjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

public class AppTest
{
    @SpringBootTest
    class DemoApplicationTests {

        @Test
        void contextLoads() {
        }

    }
}
