package com.howtodoinjava;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AppTest {

  @Test
  public void contextLoads() {
    Assertions.assertTrue(true);
  }
}
