package com.howtodoinjava;

import org.junit.jupiter.api.Test;

public class AppTest
{
    @Test
    public void contextLoads()
    {
    }
}
